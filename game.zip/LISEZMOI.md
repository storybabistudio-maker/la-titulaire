# TITULAIRE — le jeu (Ren'Py 8.5.3, format portrait 1080x1920)

## Jouer sur le Mac
```bash
~/renpy/renpy.app/Contents/MacOS/renpy ~/STORYBABI/jeu/titulaire
```

## Vérifier le jeu (Hervé)
```bash
~/renpy/renpy.app/Contents/MacOS/renpy ~/STORYBABI/jeu/titulaire lint
~/renpy/renpy.app/Contents/MacOS/renpy ~/STORYBABI/jeu/titulaire test ep1
~/renpy/renpy.app/Contents/MacOS/renpy ~/STORYBABI/jeu/titulaire test ep1::chrono_epuise   # un seul test
```
Captures d'écran (écrites dans `tests/screenshots/tests/`) :
```bash
~/renpy/renpy.app/Contents/MacOS/renpy ~/STORYBABI/jeu/titulaire test captures --overwrite-screenshots
~/renpy/renpy.app/Contents/MacOS/renpy ~/STORYBABI/jeu/titulaire test interface --overwrite-screenshots   # captures d'Essi
```
Pour qu'un test bloqué ne tourne pas indéfiniment : préfixer par `perl -e 'alarm 200; exec @ARGV'`.

## Les fichiers
| Fichier | Contenu |
|---|---|
| `game/script.rpy` | Épisode 1 « Petit dépôt » : 5 scènes, 7 menus de choix |
| `game/personnages.rpy` | Personnages, sprites (tenues x expressions), visages, décors, positions |
| `game/systeme.rpy` | Téléphone WhatsApp, gros plan du téléphone, statuts vidéo/texte, fouille chronométrée (PT, indice, pénalité) |
| `game/progression.rpy` | **Réglages des PT, étoiles, seuils** ; barres 0-100, notifications, badges, mensonges, dépôts et emprunts, choix verrouillés, « Rejouer ce choix », bilan de fin |
| `game/cauris.rpy` | **Codes promo, prix, gains, packs, défis, lien du jeu** ; cauris (persistent), bonus du jour, partage, parrainage ; écrans Cauris, Boutique, Codes, Parrainage |
| `game/ecrans_progression.rpy` | Barre du haut, écran Stats, popup « Badge débloqué », carte de choix verrouillée, écran de fin |
| `game/testcases.rpy` | 9 tests ep1 (parcours, pénalités, verrou, rejouer, codes, bonus) + la suite de captures |

## Système de jeu (référence : `histoire-01/systeme-de-jeu.md`)

### Où modifier quoi
| Je veux changer… | Fichier | Où |
|---|---|---|
| Les **codes promo** | `game/cauris.rpy` | `define CODES_PROMO` tout en haut : `"CODE": cauris`, en majuscules (le joueur peut taper en minuscules). Chaque code ne sert qu'une fois par joueur. |
| Les **prix** en cauris (choix verrouillé, indice, rejouer, tenue, avant-première) | `game/cauris.rpy` | `define PRIX` |
| Les **gains** en cauris (fin d'épisode, 3 étoiles, badge, jour, 7e jour, partage, défi, parrainage) | `game/cauris.rpy` | `define GAINS` |
| Les **packs** de la boutique (nom, cauris, prix FCFA, icône) | `game/cauris.rpy` | `define PACKS` |
| Le **lien** de la carte à partager | `game/cauris.rpy` | `define LIEN_JEU` (lien de remplacement pour l'instant) |
| Les **défis du jour** | `game/cauris.rpy` | `define DEFIS` (texte + condition vérifiée en fin d'épisode) |
| Les **Points Titulaire** par action | `game/progression.rpy` | `define PT_GAINS` |
| Les **seuils des étoiles** (1 000 et 1 800 PT) | `game/progression.rpy` | `define SEUILS_ETOILES` |
| Le seuil des choix audacieux (Fierté 20), de Gbaïrai (70), l'intérêt d'un emprunt (10 %) | `game/progression.rpy` | `FIERTE_AUDACE`, `GBAIRAI_SEUIL`, `INTERET_EMPRUNT` |
| Les badges (nom, condition affichée) | `game/progression.rpy` | `define BADGES` |
| Les deltas d'un choix | `game/script.rpy` | `stat(fierte=10, coeur=-5)` dans le choix |

### Barres, caisse, points
- Barres de 0 à 100 (bornées) : Fierté 30, Cœur 60, Gbaïrai 0, Alliance 0, Feu 0, Humanité 0 (cachée).
  Deltas de 5 à 20. Caisse (jeton) : 97 500 F, objectif 1 500 000 F.
- `stat(fierte=10, coeur=-5)` change les barres et affiche « Fierté +10 · Cœur (Wil) −5 ».
  Fierté et Humanité qui montent ensemble = choix « classe » (+50 PT).
- `croire_mensonge(...)` / `demasquer_mensonge(...)` : un mensonge démasqué rapporte +50 PT ;
  `croire_mensonge(evident=True, ...)` retire en plus Fierté −5 (le talon « pour l'ampoule »).
- Fouille : +100 PT par objet, +200 quand les 5 objets sont trouvés, +5 PT par seconde restante
  si les 6 lieux sont fouillés avant la fin (et badge Fouilleuse d'élite). Fin d'épisode +300 PT.
- Équilibrage vérifié par les tests : partie « fière » ≈ 1 870 PT (3 étoiles, Fierté 70, Cœur 25) ;
  partie « amoureuse » = 700 PT (1 étoile, Fierté 10, Cœur 95, caisse 71 750 F, Gaou certifiée).

### Badges
Fouilleuse d'élite, Banque fermée, Reine du statut, Mange ton ampoule, Gaou certifiée.
`gagner_badge("ampoule")` : +100 PT pour la partie ; la toute première fois (persistent) il rapporte
aussi +5 cauris et affiche « BADGE DÉBLOQUÉ ! » (ensuite « BADGE OBTENU », +100 PT seulement).

### Pénalités
- Chrono à 0 avec une carte d'objet ouverte → label `ep1_surprise` : Cœur −15, `persistent.wil_mefiant`.
- Caisse trop basse pour un dépôt → le choix `(cout=25000)` est grisé, et `"Emprunter…" if manque(25000)`
  apparaît : `emprunter(25000, "Chantou")` (dette +10 % dans `persistent.dettes`, Gbaïrai +5).
  Mécanisme générique, à réutiliser tel quel dans les autres épisodes (voir l'en-tête dans `progression.rpy`).
- Gbaïrai > 70 en fin d'épisode → `persistent.gbairai_haut` (revenu du salon −30 % à l'épisode 2).
- Fierté < 20 → les choix `(audace=True)` sont verrouillés (« Pri n'a plus la force »).
- Ces drapeaux pour l'épisode 2 sont remis à zéro au début de chaque partie de l'épisode 1.

### Choix verrouillés
Arguments de menu de Ren'Py 8 : `"Lui verser le garba sur la tête" (fierte=40, audace=True):`.
Si la barre est trop basse : carte grisée, cadenas dessiné, « Fierté 40 requise » et « Débloquer — 15 »
(cauris). Sans assez de cauris, le bouton ouvre l'écran Cauris. Dans l'épisode 1 : le garba (Fierté 40),
« Menaçante » (Fierté 50), « Directe » (audacieux : Fierté 20). Il reste toujours un choix libre.

### Rejouer un choix (5 cauris)
Chaque choix appelle `renpy.fix_rollback()` : le bouton Retour permet toujours de relire, mais un choix
déjà fait est figé. Revenu sur un menu avec Retour, le bouton « Rejouer ce choix — 5 » le libère (on ne
défige que ce menu, le reste du passé reste figé). Testé par `ep1::rejouer_choix`.
Limite : cela touche à `renpy.game.log.forward` (interne à Ren'Py) ; à revérifier à chaque mise à jour de Ren'Py.

### Cauris (persistent, partagés entre parties et épisodes)
- Gains : fin d'épisode +10 (1 fois par épisode), 3 étoiles +10 (1 fois), nouveau badge +5, bonus du jour
  +2 au menu principal (une fois par jour réel, +10 le 7e jour d'affilée), défi du jour +3, partage de la
  carte +5 (1 fois par jour), codes promo, parrainage +10 (filleul).
- Dépenses : choix verrouillé 15, indice de fouille 5 (bouton « Indice — 5 » : un lieu qui cache un objet
  clignote), rejouer un choix 5.
- Accès : bouton cauris sur l'accueil, « Cauris » dans le menu du jeu, barre du haut → Stats.

### Ce qui est désactivé ou attend un serveur
- **Boutique** : les 3 packs (Sachet 50 = 500 F, Panier 120 = 1 000 F, Calebasse 300 = 2 000 F) sont
  affichés, boutons désactivés « Wave / Orange Money : bientôt ». Aucun paiement n'existe.
- **Tenue bonus** (15) et **avant-première de l'épisode 2** (40) : désactivées « Bientôt ».
  `persistent.avant_premiere` est prêt pour plus tard.
- **Parrainage** : le code personnel (6 caractères, dont 1 de contrôle) vient d'un identifiant aléatoire
  (`uuid4`) créé sur l'appareil, sans donnée personnelle. Le filleul reçoit +10 une seule fois ; on ne peut
  pas entrer son propre code. Le **+20 du parrain demande un backend** : une API qui enregistre « tel code
  a parrainé tel identifiant », vérifie que le filleul a fini l'épisode 1, limite à 10 filleuls, et que le
  jeu du parrain interroge au lancement pour créditer ses cauris. Aucun faux gain n'est donné en attendant.
- **Copier le code** : marche sur ordinateur et Android, pas sur le web (Ren'Py ne sait pas copier dans le
  presse-papiers du navigateur) ; le bouton « Envoyer sur WhatsApp » marche partout.
- Les codes promo sont dans le jeu : quelqu'un qui lit les fichiers du jeu peut les voir. Un vrai contrôle
  demandera aussi le serveur.

## Contrat de nommage des images
Un fichier copié au bon endroit est pris en compte **au prochain lancement du jeu** (le code teste
`renpy.loadable()` au démarrage). Aucune ligne de code à toucher. Un fichier qui manque ne plante pas
le jeu : il y a toujours un repli.

### Sprites (corps en pied) : `game/images/sprites/<perso>_<tenue>_<exp>.png`
- Expressions : `neutre`, `fachee`, `choquee`, `triste`, `rire`, `gene`.
- Tenues (la première est celle par défaut) :
  - `pri` : `tablier`, `sachet` (arrivée chez Wil, sachet de garba à la main), `soir` (studio, woro-woro, chambre)
  - `wil` : `maillot`, `serviette` (sortie de douche)
  - `chantou`, `grace`, `cliente`, `chauffeur`, `naomi`, `jm` : `defaut`
- Fichiers d'origine (pipeline d'Ange, ne pas renommer) : `pri.png` = pri tablier neutre,
  `wil.png` = wil maillot neutre, `chantou.png` = chantou defaut choquee, les autres `<perso>.png` = defaut neutre.
- Ordre de repli : `<perso>_<tenue>_<exp>.png` → corps de base de la tenue (`<perso>_<tenue>_neutre.png`)
  → `<perso>.png`.
- Toutes les images sont ramenées à 1500 px de haut à l'affichage.
- Dans le script : `show pri soir fachee` puis `show pri choquee` → la tenue `soir` est conservée.

### Visages (side images) : `game/images/side/<perso>_<tenue>_<exp>.png`
- Repli : `side/<perso>_<tenue>_<exp>.png` → `side/<perso>_<exp>.png`.
- Pri `sachet` utilise les visages de `soir` (`side/pri_soir_<exp>.png`, braids lâchées).
- Un perso qui parle sans être à l'écran affiche `side/<perso>_neutre.png`, ou l'expression
  donnée dans la réplique (`cliente rire "…"`).

### Décors : `game/images/bg <lieu>.png` (1080x1920)
`bg salon.png`, `bg studio.png`, `bg woroworo.png`, `bg chambre.png`. Repli : aplat coloré avec le nom du lieu.

### Objets de la fouille : `game/images/objets/<objet>.png`
`talon.png` (sous le lit), `blender.png` (salle de bain), `crampons.png` (placard), `garba.png`
(poubelle : sachets vides). Repli : un cadre avec le nom de l'objet.
Le **reçu de bijouterie** (poche du jean) est dessiné par le moteur (pas d'image : l'IA écrit mal le texte).
« Sous le matelas » n'a pas d'image : la carte dit « Rien. Pas un billet. ».

### Statuts WhatsApp : `game/images/statuts/<nom>.png`
`nao_wil_cuisine.png` (statut « vidéo » du woro-woro, portrait). Repli : cadre gris avec la description.
Le statut de la chambre (2h14) est un statut texte : rien à fournir.

## La fouille : régler le chrono
- Durée : `default fouille_duree = 60` dans `game/systeme.rpy` (en secondes).
- En test ou en console (Maj+O), une fois la partie commencée : `$ fouille_duree = 10`.
- Le chrono s'affiche en grand (00:60 → 00:00), passe en rouge sous 10 s, et ne s'arrête jamais,
  même quand une carte « objet trouvé » est ouverte. Fin à 0 s ou quand les 6 lieux sont fouillés.

## Gros plan du téléphone
```renpy
call gros_plan_tel("Wil la Pépite", "Mon og tu es où ?", "21:32")               # notification
call gros_plan_tel("Ma Cocody", "", "23:41", appel=True, retourne=True)          # appel, téléphone retourné
```
Tout est dessiné dans le moteur (aucun fichier image). Un clic continue.

## Branchement du son (Kader)
Voir `~/STORYBABI/son/integration_sons_ep1.rpy.txt`. La fouille appelle toute seule `son_fouille(lieu)`
et `son_fouille_alerte()` s'ils existent (fichier `sons.rpy`).

- Ren'Py 8.5 sait afficher les emojis en couleur (police Twemoji intégrée), mais on n'en met
  pas dans le texte du jeu pour garder un rendu identique partout : la fleur de « Ma Cocody »
  est dessinée par le moteur.
